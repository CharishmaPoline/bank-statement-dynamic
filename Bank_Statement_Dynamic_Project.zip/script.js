fetch("data.json")
  .then(response => response.json())
  .then(data => {
    document.getElementById("name").textContent = data.name;
    document.getElementById("account").textContent = data.account;
    document.getElementById("month").textContent = data.month;

    const tableBody = document.getElementById("transactions");

    data.transactions.forEach(txn => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${txn.date}</td>
        <td>${txn.description}</td>
        <td>${txn.amount}</td>
        <td>${txn.type}</td>
        <td>${txn.balance}</td>
      `;
      tableBody.appendChild(row);
    });
  })
  .catch(error => {
    console.error("Error loading data:", error);
  });
