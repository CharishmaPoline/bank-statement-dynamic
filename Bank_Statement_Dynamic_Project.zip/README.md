# 💳 Bank Statement Template (Dynamic with HTML + CSS + JSON + JS)

This project is a dynamic bank statement template designed using HTML, CSS, and JavaScript. Transaction data is stored in a JSON file and auto-loaded into the webpage using `fetch()`.

## 📦 Features:
- Auto-fills name, account number, and month
- Dynamically displays transaction records
- Clean and professional table layout
- Print-ready layout using only frontend tools

## 🔧 Tools Used:
- HTML5
- CSS3
- JavaScript (fetch API, DOM manipulation)
- JSON (data storage)

## 🚀 How to Run:
1. Open the folder in VS Code
2. Install Live Server extension (if not installed)
3. Right-click `index.html` → "Open with Live Server"

## 📄 Sample Output:
| Date       | Description      | Amount     | Type    | Balance  |
|------------|------------------|------------|---------|----------|
| 01-Mar-2025| Salary           | + ₹50,000  | Credit  | ₹50,000  |
| 03-Mar-2025| Amazon Purchase  | - ₹2,500   | Debit   | ₹47,500  |

---
Made with 💻 by Charishma Polineni
